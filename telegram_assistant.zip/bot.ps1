﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$token = "9091267491:AAGEsPavlSriCCLXbiW-9sHQb5fPDRY7MS0"
$baseUrl = "https://api.telegram.org/bot$token"
$dataDir = "C:\Users\pcm\.gemini\antigravity\scratch\telegram_assistant"
$configFile = Join-Path $dataDir "config.json"
$inboxFile = Join-Path $dataDir "inbox.jsonl"
$historyFile = Join-Path $dataDir "history.json"
$notesFile = Join-Path $dataDir "notes.txt"
$logFile = Join-Path $dataDir "bot.log"

if (-not (Test-Path $configFile)) {
    @{ gemini_key = "" } | ConvertTo-Json | Set-Content -Path $configFile -Encoding UTF8
}

function Write-BotLog($msg) {
    $time = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    Add-Content -Path $logFile -Value "[$time] $msg" -Encoding UTF8
}

function Send-TelegramMessage($chatId, $text) {
    if ($text.Length -gt 4000) {
        $text = $text.Substring(0, 3990) + "`n`n... [تم اختصار النص لطوله]"
    }
    $bodyObj = @{
        chat_id = $chatId
        text = $text
    }
    $json = $bodyObj | ConvertTo-Json -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    try {
        Invoke-RestMethod -Uri "$baseUrl/sendMessage" -Method Post -ContentType "application/json; charset=utf-8" -Body $bytes | Out-Null
        Write-BotLog "Sent message to $chatId"
    } catch {
        Write-BotLog "Error sending message: $_"
    }
}

function Get-GeminiResponse($apiKey, $prompt) {
    try {
        $tempPromptFile = Join-Path $dataDir "temp_prompt.json"
        
        # Load history
        $history = @()
        if (Test-Path $historyFile) {
            try {
                $rawHist = Get-Content -Path $historyFile -Raw -Encoding UTF8
                if (-not [string]::IsNullOrWhiteSpace($rawHist)) {
                    $history = @($rawHist | ConvertFrom-Json)
                }
            } catch {}
        }
        
        # Add current user prompt
        $history += @{
            role = "user"
            parts = @(@{ text = $prompt })
        }
        
        # Keep only last 10 messages
        if ($history.Count -gt 10) {
            $history = $history[($history.Count - 10)..($history.Count - 1)]
        }
        
        $systemPrompt = @"
أنت 'عون'، الوكيل التنفيذي والمساعد الذكي لأستاذ محمد، تعمل من خلال Antigravity على لابتوبه.
السياق الحالي لمشروعكما:
1. قمتما ببناء هذا البوت نفسه ومعه ملفات server.py و Dockerfile في مسار المشروع C:\Users\pcm\.gemini\antigravity\scratch\telegram_assistant.
2. الهدف الحالي: تشغيل هذا البوت على سيرفر سحابي مجاني (مثل Render.com أو PythonAnywhere) ليعمل 24/7 واللابتوب مغلق ومطفأ.
3. الوقت المتوقع لإتمام النشر هو أقل من 5 دقائق.
قواعد صارمة جداً في الرد:
- ممنوع منعاً باتاً أي عبارات ترحيب أو مجاملات في بداية الرد (مثل: أهلاً بك، مرحباً، يا أستاذ محمد، بصفتي مساعدك).
- ادخل في الجواب والخطوات العملية فوراً وبشكل مباشر ومختصر.
- اعتمد على سياق المشروع والمحادثات السابقة دائماً ولا تناقضها.
"@

        $payloadObj = @{
            systemInstruction = @{
                parts = @(
                    @{ text = $systemPrompt }
                )
            }
            contents = $history
        }
        
        $json = $payloadObj | ConvertTo-Json -Depth 6 -Compress
        [System.IO.File]::WriteAllText($tempPromptFile, $json, [System.Text.Encoding]::UTF8)
        
        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"
        $rawOutput = curl.exe -4 -s -X POST $url -H "Content-Type: application/json" -d "@$tempPromptFile"
        
        $resp = $rawOutput | ConvertFrom-Json
        if ($resp.candidates -and $resp.candidates.Count -gt 0) {
            $replyText = $resp.candidates[0].content.parts[0].text
            
            # Save model response to history
            $history += @{
                role = "model"
                parts = @(@{ text = $replyText })
            }
            if ($history.Count -gt 10) {
                $history = $history[($history.Count - 10)..($history.Count - 1)]
            }
            $history | ConvertTo-Json -Depth 6 | Set-Content -Path $historyFile -Encoding UTF8
            
            return $replyText
        }
        if ($resp.error) {
            Write-BotLog "Gemini API error: $($resp.error.message)"
            return "⚠️ تنبيه من محرك الذكاء الاصطناعي: $($resp.error.message)"
        }
        return "عذراً، لم أتمكن من الحصول على إجابة."
    } catch {
        Write-BotLog "Gemini API exception: $_"
        return "⚠️ حدث خطأ أثناء المعالجة: $($_.Exception.Message)"
    }
}

function Get-SystemStats {
    try {
        $comp = $env:COMPUTERNAME
        $os = (Get-CimInstance Win32_OperatingSystem).Caption
        $osInfo = Get-CimInstance Win32_OperatingSystem
        $totalRamGB = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 1)
        $freeRamGB = [math]::Round($osInfo.FreePhysicalMemory / 1MB, 1)
        $usedRamGB = [math]::Round($totalRamGB - $freeRamGB, 1)
        
        $disk = Get-PSDrive C
        $freeDiskGB = [math]::Round($disk.Free / 1GB, 1)
        $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
        $batteryStr = if ($battery) { "$($battery.EstimatedChargeRemaining)%" } else { "مكتبي/متصل" }
        
        return "💻 تقرير أداء اللابتوب:`n" +
               "• الجهاز: $comp`n" +
               "• الرام: $usedRamGB GB مستخدم من $totalRamGB GB`n" +
               "• القرص (C): متبقي $freeDiskGB GB فارغ`n" +
               "• البطارية: $batteryStr`n" +
               "• الحالة: متصل بنشاط 🟢"
    } catch {
        return "💻 الجهاز متصل ويعمل بنجاح!"
    }
}

Write-BotLog "Memory-Aware Bot service started for AwnAssistant_bot..."
$offset = 0

while ($true) {
    try {
        $updatesUrl = "$baseUrl/getUpdates?offset=$offset&timeout=15"
        $response = Invoke-RestMethod -Uri $updatesUrl -Method Get -TimeoutSec 25
        
        $updates = @($response.result)
        if ($response.ok -and $updates.Count -gt 0) {
            foreach ($update in $updates) {
                $offset = $update.update_id + 1
                
                if ($update.message) {
                    $chatId = $update.message.chat.id
                    $senderName = if ($update.message.from.first_name) { $update.message.from.first_name } else { "أستاذ محمد" }
                    $text = if ($update.message.text) { $update.message.text.Trim() } else { "" }
                    
                    if ([string]::IsNullOrWhiteSpace($text)) { continue }
                    
                    Write-BotLog "Received from $senderName ($chatId): $text"
                    
                    # Record to inbox
                    $inboxEntry = @{
                        timestamp = (Get-Date).ToString("o")
                        chat_id = $chatId
                        sender = $senderName
                        text = $text
                    } | ConvertTo-Json -Compress
                    Add-Content -Path $inboxFile -Value $inboxEntry -Encoding UTF8
                    
                    # Read config
                    $config = Get-Content -Path $configFile -Raw -Encoding UTF8 | ConvertFrom-Json
                    
                    # Commands
                    if ($text -eq "/start") {
                        $reply = "تم الاتصال بنجاح. أنا 'عون' - وكيلك ومساعدك التنفيذي الذكي.`n`n" +
                                 "⚡ الأوامر المباشرة:`n" +
                                 "• /status - فحص موارد اللابتوب`n" +
                                 "• /note [نص] - حفظ ملاحظة أو فكرة`n" +
                                 "• /notes - استعراض الملاحظات`n" +
                                 "• /cmd [أمر] - تشغيل أوامر PowerShell على لابتوبك`n`n" +
                                 "أو اكتب أي سؤال أو مهمة مباشرة وسأجيبك فوراً بدقة وسياق كامل."
                        Send-TelegramMessage $chatId $reply
                    }
                    elseif ($text -eq "/status") {
                        $reply = Get-SystemStats
                        Send-TelegramMessage $chatId $reply
                    }
                    elseif ($text.StartsWith("/note ")) {
                        $noteContent = $text.Substring(6).Trim()
                        $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm")
                        Add-Content -Path $notesFile -Value "[$timestamp] $noteContent" -Encoding UTF8
                        Send-TelegramMessage $chatId "تم حفظ الملاحظة:`n`"$noteContent`""
                    }
                    elseif ($text -eq "/notes") {
                        if (Test-Path $notesFile) {
                            $notes = Get-Content -Path $notesFile -Encoding UTF8 -Raw
                            if ([string]::IsNullOrWhiteSpace($notes)) {
                                Send-TelegramMessage $chatId "لا توجد ملاحظات محفوظة."
                            } else {
                                Send-TelegramMessage $chatId "ملاحظاتك المسجلة:`n`n$notes"
                            }
                        } else {
                            Send-TelegramMessage $chatId "لا توجد ملاحظات محفوظة."
                        }
                    }
                    elseif ($text.StartsWith("/cmd ")) {
                        $cmd = $text.Substring(5).Trim()
                        try {
                            $cmdOutput = powershell -NoProfile -Command $cmd 2>&1 | Out-String
                            if ([string]::IsNullOrWhiteSpace($cmdOutput)) { $cmdOutput = "تم التنفيذ بدون مخرجات." }
                            Send-TelegramMessage $chatId "🖥️ مخرجات الأمر:`n$cmdOutput"
                        } catch {
                            Send-TelegramMessage $chatId "❌ خطأ أثناء التنفيذ: $_"
                        }
                    }
                    else {
                        # Normal message: Send to Gemini with full history and context
                        if (-not [string]::IsNullOrWhiteSpace($config.gemini_key)) {
                            $aiReply = Get-GeminiResponse -apiKey $config.gemini_key -prompt $text
                            Send-TelegramMessage $chatId $aiReply
                        } else {
                            $reply = "وصلتني رسالتك: `"$text`"`nيرجى ربط المفتاح بكتابة: /key [api_key]"
                            Send-TelegramMessage $chatId $reply
                        }
                    }
                }
            }
        }
    } catch {
        Write-BotLog "Polling error: $_"
        Start-Sleep -Seconds 2
    }
    
    Start-Sleep -Milliseconds 300
}
